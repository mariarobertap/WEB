console.log('Maria Roberta, 11/09/2021')

const keys = document.querySelectorAll('.key')
const whiteKeys = document.querySelectorAll('.key.white')
const blackKeys = document.querySelectorAll('.key.black')

keys.forEach(key => {
  key.addEventListener('click', () => playNote(key))
})

function playNote(key) {
  const noteAudio = document.getElementById(key.dataset.note)
  noteAudio.currentTime = 0


  noteAudio.play()
  key.classList.add('active')


  setTimeout(() => { 
    key.classList.remove('active')
    }, 300);

}